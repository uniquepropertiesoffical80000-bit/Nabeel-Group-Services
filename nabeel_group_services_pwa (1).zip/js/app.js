/* Complete Frontend, Database Layer & Admin Dashboard for Nabeel Group of Services */

// Default Demo Data & LocalStorage Management
const DB_KEYS = {
    businesses: 'nabeel_businesses',
    properties: 'nabeel_properties',
    soldProperties: 'nabeel_sold_properties',
    materials: 'nabeel_materials',
    clients: 'nabeel_clients',
    enquiries: 'nabeel_enquiries',
    payments: 'nabeel_payments',
    followups: 'nabeel_followups'
};

const defaultData = {
    businesses: [
        { id: 1, name: "NABEEL CONSTRUCTION", icon: "fa-helmet-safety", desc: "Expert residential & commercial building construction, renovation, planning, and turnkey project execution.", tags: ["Residential", "Commercial", "Turnkey", "Renovation"] },
        { id: 2, name: "NABEEL ELECTRICAL SERVICES", icon: "fa-bolt", desc: "Professional electrical wiring, panel work, industrial installations, decorative lighting & emergency repairs.", tags: ["Wiring", "Panels", "Lighting", "Maintenance"] },
        { id: 3, name: "NABEEL CCTV SERVICES", icon: "fa-video", desc: "High-definition HD/IP CCTV installation, DVR/NVR setup, mobile live view, and security system maintenance.", tags: ["HD/IP Cameras", "DVR/NVR", "Remote View", "Security"] },
        { id: 4, name: "NABEEL BUILDING MATERIALS SUPPLIER", icon: "fa-truck-ramp-box", desc: "Top-quality construction materials supplier including sand, aggregate, bricks, murum, and essential supplies.", tags: ["Sand / रेती", "Aggregate / गिट्टी", "Bricks / ईंट", "Murum"] },
        { id: 5, name: "UNIQUE PROPERTIES", icon: "fa-building-columns", desc: "Leading real estate developers and property consultants offering prime plots, flats, and commercial spaces in Nanded.", tags: ["Plots", "Houses", "Commercial", "Consultancy"] }
    ],
    properties: [
        { id: 1, title: "Prime Residential Plot", project: "Nabeel Enclave Phase 1", location: "Degloor Naka, Nanded", number: "Plot No. 42", size: "30 x 50 sq.ft", area: "1500 sq.ft", pricePerSqFt: 1200, total: 1800000, docs: "Clear Title, NA Order, Registry Ready", owner: "Er. Syed Abubakar Noman", contact: "7776000339", desc: "East facing prime residential plot near main road with 40ft wide CC road and water connection.", status: "Available", image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&auto=format&fit=crop&q=80" },
        { id: 2, title: "Commercial Complex Shop", project: "Nabeel Trade Center", location: "Main Road, Nanded", number: "Shop No. 102", size: "20 x 25 sq.ft", area: "500 sq.ft", pricePerSqFt: 4500, total: 2250000, docs: "Commercial Sanctioned, Property Tax Paid", owner: "Er. Syed Abubakar Noman", contact: "9011146695", desc: "Ground floor heavy footfall commercial shop ideal for showroom, clinic or office.", status: "Available", image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&auto=format&fit=crop&q=80" },
        { id: 3, title: "Luxury Duplex Villa", project: "Nabeel Green Valley", location: "CIDCO, Nanded", number: "House No. B-15", size: "40 x 60 sq.ft", area: "2400 sq.ft", pricePerSqFt: 3500, total: 8400000, docs: "Sanctioned Plan, Loan Available", owner: "Er. Syed Abubakar Noman", contact: "7776000339", desc: "Brand new 4 BHK luxury duplex villa with premium fittings, parking and rooftop terrace.", status: "Reserved", image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&auto=format&fit=crop&q=80" }
    ],
    soldProperties: [
        { id: 101, title: "Residential Plot", project: "Nabeel Enclave", location: "Degloor Naka, Nanded", number: "Plot No. 12", size: "30 x 40 sq.ft", area: "1200 sq.ft", soldPrice: 1100, total: 1320000, purchaseDate: "2025-06-15", registryDate: "2025-06-28", purchaserName: "Mr. Rajesh Kulkarni", purchaserContact: "9822012345", details: "Corner plot with park view.", docs: "Registered Sale Deed" },
        { id: 102, title: "Independent House", project: "Nabeel Heights", location: "Vazirabad, Nanded", number: "House No. 4", size: "25 x 45 sq.ft", area: "1125 sq.ft", soldPrice: 3200, total: 3600000, purchaseDate: "2025-09-10", registryDate: "2025-09-25", purchaserName: "Dr. Sandeep Deshmukh", purchaserContact: "9422178900", details: "3 BHK ready to move house.", docs: "Registered Sale Deed" }
    ],
    materials: [
        { id: 1, name: "River Sand (रेती)", category: "Sand", desc: "Fine quality construction river sand for plastering and slab casting.", quantity: 500, unit: "Brass", price: 5500, status: "In Stock", image: "https://images.unsplash.com/photo-1578575437130-527eed3abbec?w=600&auto=format&fit=crop&q=80" },
        { id: 2, name: "Blue Metal Aggregate (गिट्टी - 20mm)", category: "Aggregate", desc: "High strength crushed stone aggregate for RCC concrete works.", quantity: 1000, unit: "Brass", price: 3800, status: "In Stock", image: "https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?w=600&auto=format&fit=crop&q=80" },
        { id: 3, name: "Red Bricks (लाल ईंट)", category: "Bricks", desc: "First class premium kiln burnt red clay bricks.", quantity: 25000, unit: "Pieces", price: 8, status: "In Stock", image: "https://images.unsplash.com/photo-1590381105924-c72589b9ef3f?w=600&auto=format&fit=crop&q=80" },
        { id: 4, name: "Murum / Filling Material", category: "Murum", desc: "Good quality red/black murum for foundation filling and leveling.", quantity: 800, unit: "Brass", price: 2200, status: "In Stock", image: "https://images.unsplash.com/photo-1584467735811-62868fb7a249?w=600&auto=format&fit=crop&q=80" }
    ],
    clients: [
        { id: 1, name: "Mr. Rajesh Kulkarni", mobile: "9822012345", whatsapp: "9822012345", service: "Unique Properties", requirement: "Purchased Plot No. 12", location: "Nanded", status: "Converted", notes: "Registry completed successfully." },
        { id: 2, name: "Mr. Amit Shinde", mobile: "9765432100", whatsapp: "9765432100", service: "Nabeel Construction", requirement: "Duplex construction turnkey", location: "Degloor Naka", status: "Interested", notes: "Plan finalization in progress." }
    ],
    enquiries: [
        { id: 1, name: "Mr. Amit Shinde", mobile: "9765432100", whatsapp: "9765432100", email: "amit@gmail.com", service: "Nabeel Construction", propertyReq: "Duplex House", location: "Degloor Naka", budget: "55 Lakhs", details: "Looking for complete turnkey construction.", date: "2026-03-30", status: "New" }
    ],
    payments: [
        { id: 1, client: "Mr. Rajesh Kulkarni", purchaser: "Mr. Rajesh Kulkarni", contact: "9822012345", property: "Plot No. 12, Nabeel Enclave", total: 1320000, paid: 1320000, date: "2025-06-28", mode: "Bank Transfer", txn: "TXN9832112", registry: "2025-06-28", notes: "Full payment received." },
        { id: 2, client: "Dr. Sandeep Deshmukh", purchaser: "Dr. Sandeep Deshmukh", contact: "9422178900", property: "House No. 4, Vazirabad", total: 3600000, paid: 2000000, date: "2025-09-10", mode: "Cheque", txn: "CHQ44210", registry: "2025-09-25", notes: "Balance pending." }
    ],
    followups: [
        { id: 1, date: "2026-04-05", time: "11:00 AM", client: "Mr. Amit Shinde", contact: "9765432100", purpose: "Site Visit Discussion", service: "Nabeel Construction", notes: "Discuss structural drawings.", status: "Pending" }
    ]
};

// Initialize LocalStorage DB
function initDB() {
    for (let key in DB_KEYS) {
        if (!localStorage.getItem(DB_KEYS[key])) {
            localStorage.setItem(DB_KEYS[key], JSON.stringify(defaultData[key]));
        }
    }
}
initDB();

function getDB(key) {
    return JSON.parse(localStorage.getItem(DB_KEYS[key])) || [];
}

function saveDB(key, data) {
    localStorage.setItem(DB_KEYS[key], JSON.stringify(data));
}

// Router & Navigation
window.addEventListener('hashchange', handleRoute);
window.addEventListener('load', handleRoute);

function router(route) {
    window.location.hash = route;
}

function handleRoute() {
    const hash = window.location.hash.replace('#', '') || 'home';
    
    // Update active nav links
    document.querySelectorAll('.nav-link, .b-nav-item').forEach(el => el.classList.remove('active'));
    const activeNav = document.querySelector(`[onclick*="${hash}"]`);
    if(activeNav) activeNav.classList.add('active');

    const main = document.getElementById('app-main');
    window.scrollTo(0, 0);

    switch(hash) {
        case 'home': renderHome(main); break;
        case 'businesses': renderBusinesses(main); break;
        case 'properties': renderProperties(main); break;
        case 'sold': renderSoldProperties(main); break;
        case 'materials': renderMaterials(main); break;
        case 'requirement': renderRequirement(main); break;
        case 'contact': renderContact(main); break;
        case 'admin': renderAdmin(main); break;
        default: renderHome(main); break;
    }
}

// Toggle Mobile Drawer
const mobileToggle = document.getElementById('mobileMenuToggle');
const closeDrawerBtn = document.getElementById('closeDrawer');
const mobileDrawer = document.getElementById('mobileDrawer');

if(mobileToggle) mobileToggle.addEventListener('click', () => mobileDrawer.classList.add('open'));
if(closeDrawerBtn) closeDrawerBtn.addEventListener('click', () => mobileDrawer.classList.remove('open'));
function toggleDrawer() {
    if(mobileDrawer) mobileDrawer.classList.toggle('open');
}

// WhatsApp Helper
function sendWhatsAppMessage(text) {
    const phone = "917776000339";
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
}

/* --- 1. HOMEPAGE --- */
function renderHome(container) {
    const businesses = getDB('businesses');
    const properties = getDB('properties').filter(p => p.status === 'Available');

    container.innerHTML = `
        <section class="hero-section">
            <div class="container hero-content">
                <div class="hero-badge"><i class="fa-solid fa-certificate"></i> Prop. Er. Syed Abubakar Noman</div>
                <h1>NABEEL GROUP OF SERVICES</h1>
                <p class="hero-subtitle">“Construction • Electrical • CCTV • Building Materials • Real Estate”</p>
                <p class="hero-desc">Your trusted single-window platform for premier construction, professional electrical and CCTV security services, top-grade building materials, and luxury real estate in Nanded.</p>
                <div class="hero-buttons">
                    <button class="btn btn-gold" onclick="router('businesses')"><i class="fa-solid fa-compass"></i> Explore Our Businesses</button>
                    <button class="btn btn-outline" onclick="router('requirement')"><i class="fa-solid fa-paper-plane"></i> Send Your Requirement</button>
                    <button class="btn btn-whatsapp" onclick="sendWhatsAppMessage('Hello Nabeel Group, I would like to inquire about your services.')"><i class="fa-brands fa-whatsapp"></i> Chat on WhatsApp</button>
                </div>
            </div>
        </section>

        <!-- About Owner Section -->
        <section class="section-padding">
            <div class="container">
                <div class="form-card" style="text-align: center; background: linear-gradient(135deg, #0B132B, #1C2541); color: #fff;">
                    <div style="font-size: 3rem; color: var(--gold); margin-bottom: 15px;"><i class="fa-solid fa-user-tie"></i></div>
                    <h2 style="color: #fff; margin-bottom: 10px;">Prop. Er. Syed Abubakar Noman</h2>
                    <p style="color: var(--gold); font-weight: 600; margin-bottom: 20px;">Director & Principal Engineer | Nabeel Group of Services</p>
                    <p style="color: #D1D5DB; max-width: 700px; margin: 0 auto 25px; line-height: 1.8;">Operating from Degloor Naka, Nanded, we deliver uncompromising quality, transparency, and professional execution across all our five specialized business verticals.</p>
                    <div class="hero-buttons">
                        <a href="tel:7776000339" class="btn btn-gold"><i class="fa-solid fa-phone"></i> 7776000339</a>
                        <a href="tel:9011146695" class="btn btn-outline"><i class="fa-solid fa-phone"></i> 9011146695</a>
                        <a href="https://maps.google.com/?q=Degloor+Naka+Nanded" target="_blank" class="btn btn-primary"><i class="fa-solid fa-location-dot"></i> Get Directions</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Businesses Cards Section -->
        <section class="section-padding" style="background-color: #fff;">
            <div class="container">
                <div class="section-header">
                    <h2>Our Specialized Businesses</h2>
                    <p>Five industry leaders under one unified corporate umbrella</p>
                </div>
                <div class="business-grid">
                    ${businesses.map(b => `
                        <div class="business-card">
                            <div>
                                <div class="card-icon-box"><i class="fa-solid ${b.icon}"></i></div>
                                <h3>${b.name}</h3>
                                <p>${b.desc}</p>
                                <div class="service-tags">
                                    ${b.tags.map(t => `<span class="tag">${t}</span>`).join('')}
                                </div>
                            </div>
                            <div class="card-actions">
                                <button class="btn btn-primary" onclick="router('businesses')"><i class="fa-solid fa-eye"></i> View Details</button>
                                <button class="btn btn-whatsapp" onclick="sendWhatsAppMessage('Hello Nabeel Group, I want to send requirement for ${b.name}')"><i class="fa-brands fa-whatsapp"></i> WhatsApp</button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </section>

        <!-- Featured Properties Preview -->
        <section class="section-padding">
            <div class="container">
                <div class="section-header">
                    <h2>Featured Available Properties</h2>
                    <p>Explore prime plots, commercial spaces, and luxury homes in Nanded</p>
                </div>
                <div class="properties-grid">
                    ${properties.slice(0, 3).map(p => `
                        <div class="property-card">
                            <div class="property-img-wrapper">
                                <img src="${p.image}" alt="${p.title}">
                                <span class="property-status-badge status-${p.status.toLowerCase()}">${p.status}</span>
                            </div>
                            <div class="property-details">
                                <h3>${p.title}</h3>
                                <p class="property-loc"><i class="fa-solid fa-location-dot"></i> ${p.location} (${p.project})</p>
                                <div class="property-meta-grid">
                                    <div class="meta-item"><span>Plot/No</span><strong>${p.number}</strong></div>
                                    <div class="meta-item"><span>Area</span><strong>${p.area}</strong></div>
                                </div>
                                <div class="property-price">₹ ${Number(p.total).toLocaleString('en-IN')} <span>(₹ ${p.pricePerSqFt}/sq.ft)</span></div>
                                <div class="card-actions">
                                    <button class="btn btn-gold" onclick="router('properties')"><i class="fa-solid fa-info-circle"></i> View Details</button>
                                    <a href="tel:${p.contact}" class="btn btn-primary"><i class="fa-solid fa-phone"></i> Call</a>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
                <div style="text-align: center; margin-top: 40px;">
                    <button class="btn btn-primary" onclick="router('properties')" style="padding: 14px 30px;"><i class="fa-solid fa-building"></i> View All Available Properties</button>
                </div>
            </div>
        </section>
    `;
}

/* --- 2. BUSINESSES SECTION --- */
function renderBusinesses(container) {
    const businesses = getDB('businesses');
    container.innerHTML = `
        <section class="section-padding">
            <div class="container">
                <div class="section-header">
                    <h2>Nabeel Group Business Divisions</h2>
                    <p>Professional services delivered with engineering precision</p>
                </div>
                <div class="business-grid" style="grid-template-columns: 1fr; max-width: 900px; margin: 0 auto;">
                    ${businesses.map(b => `
                        <div class="business-card" style="margin-bottom: 30px;">
                            <div style="display: flex; align-items: flex-start; gap: 20px; flex-wrap: wrap;">
                                <div class="card-icon-box" style="margin-bottom: 0;"><i class="fa-solid ${b.icon}"></i></div>
                                <div style="flex: 1;">
                                    <h3 style="font-size: 1.5rem; margin-bottom: 10px;">${b.name}</h3>
                                    <p style="font-size: 1.05rem; margin-bottom: 15px;">${b.desc}</p>
                                    <div class="service-tags" style="margin-bottom: 20px;">
                                        ${b.tags.map(t => `<span class="tag" style="padding: 6px 14px; font-size: 0.85rem;">${t}</span>`).join('')}
                                    </div>
                                    <div class="card-actions" style="justify-content: flex-start;">
                                        <button class="btn btn-gold" onclick="router('requirement')"><i class="fa-solid fa-paper-plane"></i> Request ${b.name.replace('NABEEL ', '')}</button>
                                        <button class="btn btn-whatsapp" onclick="sendWhatsAppMessage('Hello Nabeel Group, I am interested in ${b.name}. Please share details.')"><i class="fa-brands fa-whatsapp"></i> WhatsApp Enquiry</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </section>
    `;
}

/* --- 3. AVAILABLE PROPERTIES --- */
function renderProperties(container) {
    const properties = getDB('properties').filter(p => p.status === 'Available' || p.status === 'Reserved');
    container.innerHTML = `
        <section class="section-padding">
            <div class="container">
                <div class="section-header">
                    <h2>Unique Properties (Real Estate)</h2>
                    <p>Verified plots, commercial shops, and luxury houses for sale in Nanded</p>
                </div>
                <div class="properties-grid">
                    ${properties.length === 0 ? '<p style="text-align:center; grid-column: 1/-1;">No properties currently available. Check back soon or submit a requirement!</p>' : 
                    properties.map(p => `
                        <div class="property-card">
                            <div class="property-img-wrapper">
                                <img src="${p.image}" alt="${p.title}">
                                <span class="property-status-badge status-${p.status.toLowerCase()}">${p.status}</span>
                            </div>
                            <div class="property-details">
                                <h3>${p.title}</h3>
                                <p class="property-loc"><i class="fa-solid fa-location-dot"></i> ${p.location} — <strong>${p.project}</strong></p>
                                <div class="property-meta-grid">
                                    <div class="meta-item"><span>Plot / House No</span><strong>${p.number}</strong></div>
                                    <div class="meta-item"><span>Plot Size</span><strong>${p.size}</strong></div>
                                    <div class="meta-item"><span>Plot Area</span><strong>${p.area}</strong></div>
                                    <div class="meta-item"><span>Documents</span><strong>${p.docs}</strong></div>
                                </div>
                                <p style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 15px;">${p.desc}</p>
                                <div class="property-price">₹ ${Number(p.total).toLocaleString('en-IN')} <span>(₹ ${p.pricePerSqFt}/sq.ft)</span></div>
                                <div class="card-actions">
                                    <a href="tel:${p.contact}" class="btn btn-primary"><i class="fa-solid fa-phone"></i> Call</a>
                                    <button class="btn btn-whatsapp" onclick="sendWhatsAppMessage('Hello Nabeel Group, I am interested in property: ${p.title} (${p.number}, ${p.location}). Total: ₹${p.total}. Please share details.')"><i class="fa-brands fa-whatsapp"></i> WhatsApp</button>
                                    <button class="btn btn-gold" onclick="router('requirement')"><i class="fa-solid fa-paper-plane"></i> Enquire</button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </section>
    `;
}

/* --- 4. SOLD OUT PROPERTIES --- */
function renderSoldProperties(container) {
    const sold = getDB('soldProperties');
    container.innerHTML = `
        <section class="section-padding">
            <div class="container">
                <div class="section-header">
                    <h2>Sold Out Properties Archive</h2>
                    <p>Previously successfully completed real estate transactions by Unique Properties</p>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Property / Project</th>
                                <th>Location</th>
                                <th>Plot / House No</th>
                                <th>Area</th>
                                <th>Sold Price</th>
                                <th>Registry Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${sold.length === 0 ? '<tr><td colspan="7" style="text-align:center;">No sold properties recorded yet.</td></tr>' :
                            sold.map(s => `
                                <tr>
                                    <td><strong>${s.title}</strong><br><small>${s.project}</small></td>
                                    <td>${s.location}</td>
                                    <td>${s.number}</td>
                                    <td>${s.area}</td>
                                    <td><strong>₹ ${Number(s.total).toLocaleString('en-IN')}</strong></td>
                                    <td>${s.registryDate}</td>
                                    <td><span class="property-status-badge status-sold" style="position:static;">SOLD</span></td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    `;
}

/* --- 5. BUILDING MATERIALS CATALOGUE --- */
function renderMaterials(container) {
    const materials = getDB('materials');
    container.innerHTML = `
        <section class="section-padding">
            <div class="container">
                <div class="section-header">
                    <h2>Nabeel Building Materials Supplier</h2>
                    <p>High-grade construction materials available for immediate supply in Nanded</p>
                </div>
                <div class="materials-grid">
                    ${materials.map(m => `
                        <div class="material-card">
                            <div>
                                <div class="material-header">
                                    <span class="material-category">${m.category}</span>
                                    <span class="material-stock"><i class="fa-solid fa-circle-check"></i> ${m.status}</span>
                                </div>
                                <img src="${m.image}" alt="${m.name}" style="width:100%; height:140px; object-fit:cover; border-radius:8px; margin-bottom:12px;">
                                <h3>${m.name}</h3>
                                <p>${m.desc}</p>
                            </div>
                            <div>
                                <div class="material-price-row">
                                    <span>₹ ${m.price} / ${m.unit}</span>
                                    <span style="font-size:0.8rem; color:var(--text-muted); font-weight:normal;">Stock: ${m.quantity} ${m.unit}</span>
                                </div>
                                <button class="btn btn-whatsapp" style="width:100%;" onclick="sendWhatsAppMessage('Hello Nabeel Group, I want to order building material: ${m.name} at ₹${m.price}/${m.unit}. Please arrange delivery.')"><i class="fa-brands fa-whatsapp"></i> Order via WhatsApp</button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </section>
    `;
}

/* --- 6. CLIENT REQUIREMENT SYSTEM --- */
function renderRequirement(container) {
    container.innerHTML = `
        <section class="section-padding">
            <div class="container">
                <div class="section-header">
                    <h2>Send Your Requirement</h2>
                    <p>Submit your project details and instantly connect with Er. Syed Abubakar Noman via WhatsApp</p>
                </div>
                <div class="form-card">
                    <form id="requirementForm" onsubmit="submitRequirement(event)">
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Full Name *</label>
                                <input type="text" id="reqName" class="form-control" placeholder="Enter your full name" required>
                            </div>
                            <div class="form-group">
                                <label>Mobile Number *</label>
                                <input type="tel" id="reqMobile" class="form-control" placeholder="10-digit mobile number" required>
                            </div>
                            <div class="form-group">
                                <label>WhatsApp Number *</label>
                                <input type="tel" id="reqWhatsapp" class="form-control" placeholder="WhatsApp number" required>
                            </div>
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" id="reqEmail" class="form-control" placeholder="email@example.com">
                            </div>
                            <div class="form-group">
                                <label>Select Required Service / Business *</label>
                                <select id="reqService" class="form-control" required>
                                    <option value="Nabeel Construction">Nabeel Construction</option>
                                    <option value="Nabeel Electrical Services">Nabeel Electrical Services</option>
                                    <option value="Nabeel CCTV Services">Nabeel CCTV Services</option>
                                    <option value="Nabeel Building Materials Supplier">Nabeel Building Materials Supplier</option>
                                    <option value="Unique Properties (Real Estate)">Unique Properties (Real Estate)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Preferred Location in Nanded</label>
                                <input type="text" id="reqLocation" class="form-control" placeholder="e.g. Degloor Naka, CIDCO, Vazirabad">
                            </div>
                            <div class="form-group">
                                <label>Budget (Approx)</label>
                                <input type="text" id="reqBudget" class="form-control" placeholder="e.g. ₹ 25 Lakhs">
                            </div>
                            <div class="form-group">
                                <label>Preferred Contact Time</label>
                                <input type="text" id="reqTime" class="form-control" placeholder="e.g. Evening 5 PM to 7 PM">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Detailed Requirement / Notes *</label>
                            <textarea id="reqDetails" class="form-control" placeholder="Provide complete details about your construction, property, electrical, CCTV or material requirement..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-whatsapp" style="width: 100%; padding: 15px; font-size: 1.05rem; margin-top: 10px;">
                            <i class="fa-brands fa-whatsapp" style="font-size: 1.3rem;"></i> SEND REQUIREMENT ON WHATSAPP & SAVE
                        </button>
                    </form>
                </div>
            </div>
        </section>
    `;
}

function submitRequirement(e) {
    e.preventDefault();
    const name = document.getElementById('reqName').value;
    const mobile = document.getElementById('reqMobile').value;
    const whatsapp = document.getElementById('reqWhatsapp').value;
    const email = document.getElementById('reqEmail').value;
    const service = document.getElementById('reqService').value;
    const location = document.getElementById('reqLocation').value;
    const budget = document.getElementById('reqBudget').value;
    const time = document.getElementById('reqTime').value;
    const details = document.getElementById('reqDetails').value;

    // Save to Enquiries & Clients DB
    const enquiries = getDB('enquiries');
    const newEnq = { id: Date.now(), name, mobile, whatsapp, email, service, propertyReq: service, location, budget, details, date: new Date().toISOString().split('T')[0], status: 'New' };
    enquiries.push(newEnq);
    saveDB('enquiries', enquiries);

    const clients = getDB('clients');
    if(!clients.some(c => c.mobile === mobile)) {
        clients.push({ id: Date.now(), name, mobile, whatsapp, service, requirement: details, location, status: 'New', notes: 'Submitted via website requirement form.' });
        saveDB('clients', clients);
    }

    // Format professional WhatsApp message
    const waText = `NABEEL GROUP OF SERVICES – CUSTOMER REQUIREMENT\n\nName: ${name}\nMobile: ${mobile}\nService: ${service}\nLocation: ${location}\nBudget: ${budget}\nPreferred Time: ${time}\nDetails: ${details}\n\nPlease contact me regarding my requirement.`;
    
    sendWhatsAppMessage(waText);
    alert('Requirement submitted successfully and saved in Admin Dashboard! Redirecting to WhatsApp...');
    router('home');
}

/* --- 7. CONTACT PAGE --- */
function renderContact(container) {
    container.innerHTML = `
        <section class="section-padding">
            <div class="container">
                <div class="section-header">
                    <h2>Contact Nabeel Group of Services</h2>
                    <p>Get in touch with our office in Nanded</p>
                </div>
                <div class="form-card" style="margin-bottom: 40px;">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px;">
                        <div>
                            <h3 style="color: var(--primary); margin-bottom: 15px; font-size: 1.4rem;">NABEEL GROUP OF SERVICES</h3>
                            <p style="font-weight: 700; color: var(--gold); margin-bottom: 10px;">Prop. Er. Syed Abubakar Noman</p>
                            <p style="margin-bottom: 12px;"><i class="fa-solid fa-location-dot" style="color: var(--gold); margin-right: 8px;"></i> <strong>Office Address:</strong><br>Degloor Naka, Nanded – 431604</p>
                            <p style="margin-bottom: 12px;"><i class="fa-solid fa-phone" style="color: var(--gold); margin-right: 8px;"></i> <strong>Phone Numbers:</strong><br><a href="tel:7776000339">7776000339</a> / <a href="tel:9011146695">9011146695</a></p>
                            <p style="margin-bottom: 20px;"><i class="fa-solid fa-envelope" style="color: var(--gold); margin-right: 8px;"></i> <strong>Email:</strong> contact@nabeelgroup.com</p>
                            <div class="hero-buttons" style="justify-content: flex-start;">
                                <a href="tel:7776000339" class="btn btn-gold"><i class="fa-solid fa-phone"></i> Call Now</a>
                                <a href="https://wa.me/917776000339" class="btn btn-whatsapp" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
                            </div>
                        </div>
                        <div>
                            <h4 style="color: var(--primary); margin-bottom: 15px;">Business Hours</h4>
                            <p style="margin-bottom: 8px;"><strong>Monday – Saturday:</strong> 9:00 AM – 8:00 PM</p>
                            <p style="margin-bottom: 15px;"><strong>Sunday:</strong> 10:00 AM – 2:00 PM</p>
                            <div style="background: var(--bg-light); padding: 15px; border-radius: 8px; border: 1px solid var(--border-color);">
                                <h5 style="color: var(--primary); margin-bottom: 5px;"><i class="fa-solid fa-map-location-dot"></i> Location Note</h5>
                                <p style="font-size: 0.88rem; color: var(--text-muted);">Our central office is conveniently located at Degloor Naka, Nanded, providing easy accessibility for all construction, material, and real estate clients.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    `;
}

/* --- 8. SECURE ADMIN LOGIN & DASHBOARD --- */
function renderAdmin(container) {
    const isLoggedIn = sessionStorage.getItem('nabeel_admin_logged') === 'true';
    if (!isLoggedIn) {
        container.innerHTML = `
            <section class="section-padding">
                <div class="container">
                    <div class="form-card" style="max-width: 450px; text-align: center;">
                        <div style="font-size: 3rem; color: var(--danger); margin-bottom: 15px;"><i class="fa-solid fa-lock"></i></div>
                        <h2>Admin Secure Login</h2>
                        <p style="margin-bottom: 25px;">Enter credentials to access Nabeel Group Management Dashboard</p>
                        <form onsubmit="handleAdminLogin(event)">
                            <div class="form-group" style="text-align: left;">
                                <label>Username</label>
                                <input type="text" id="adminUser" class="form-control" placeholder="admin" required>
                            </div>
                            <div class="form-group" style="text-align: left;">
                                <label>Password</label>
                                <input type="password" id="adminPass" class="form-control" placeholder="admin123" required>
                            </div>
                            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 12px; margin-top: 10px;">Login to Dashboard</button>
                        </form>
                        <p style="margin-top: 15px; font-size: 0.8rem; color: var(--text-muted);">Default demo credentials: <strong>admin</strong> / <strong>admin123</strong></p>
                    </div>
                </div>
            </section>
        `;
    } else {
        renderAdminDashboard(container);
    }
}

function handleAdminLogin(e) {
    e.preventDefault();
    const u = document.getElementById('adminUser').value;
    const p = document.getElementById('adminPass').value;
    if(u === 'admin' && p === 'admin123') {
        sessionStorage.setItem('nabeel_admin_logged', 'true');
        renderAdmin(document.getElementById('app-main'));
    } else {
        alert('Invalid admin credentials! Use admin / admin123');
    }
}

function adminLogout() {
    sessionStorage.removeItem('nabeel_admin_logged');
    router('home');
}

let currentAdminTab = 'overview';

function renderAdminDashboard(container, tab = 'overview') {
    currentAdminTab = tab;
    const businesses = getDB('businesses');
    const properties = getDB('properties');
    const soldProps = getDB('soldProperties');
    const materials = getDB('materials');
    const clients = getDB('clients');
    const enquiries = getDB('enquiries');
    const payments = getDB('payments');
    const followups = getDB('followups');

    const totalPaid = payments.reduce((acc, p) => acc + Number(p.paid), 0);
    const totalAmount = payments.reduce((acc, p) => acc + Number(p.total), 0);
    const remainingAmount = totalAmount - totalPaid;

    container.innerHTML = `
        <div class="admin-wrapper">
            <div class="admin-sidebar">
                <h3>Admin Panel</h3>
                <button class="admin-menu-btn ${tab==='overview'?'active':''}" onclick="renderAdminDashboard(document.getElementById('app-main'), 'overview')"><i class="fa-solid fa-chart-pie"></i> Overview</button>
                <button class="admin-menu-btn ${tab==='businesses'?'active':''}" onclick="renderAdminDashboard(document.getElementById('app-main'), 'businesses')"><i class="fa-solid fa-briefcase"></i> Businesses</button>
                <button class="admin-menu-btn ${tab==='properties'?'active':''}" onclick="renderAdminDashboard(document.getElementById('app-main'), 'properties')"><i class="fa-solid fa-building"></i> Properties</button>
                <button class="admin-menu-btn ${tab==='sold'?'active':''}" onclick="renderAdminDashboard(document.getElementById('app-main'), 'sold')"><i class="fa-solid fa-handshake"></i> Sold Properties</button>
                <button class="admin-menu-btn ${tab==='materials'?'active':''}" onclick="renderAdminDashboard(document.getElementById('app-main'), 'materials')"><i class="fa-solid fa-cubes"></i> Materials</button>
                <button class="admin-menu-btn ${tab==='clients'?'active':''}" onclick="renderAdminDashboard(document.getElementById('app-main'), 'clients')"><i class="fa-solid fa-users"></i> Clients & Enquiries</button>
                <button class="admin-menu-btn ${tab==='payments'?'active':''}" onclick="renderAdminDashboard(document.getElementById('app-main'), 'payments')"><i class="fa-solid fa-wallet"></i> Payments</button>
                <button class="admin-menu-btn ${tab==='schedule'?'active':''}" onclick="renderAdminDashboard(document.getElementById('app-main'), 'schedule')"><i class="fa-solid fa-calendar-check"></i> Follow-ups</button>
                <button class="admin-menu-btn" onclick="adminLogout()" style="color:var(--danger); margin-top:20px;"><i class="fa-solid fa-right-from-bracket" style="color:var(--danger);"></i> Logout</button>
            </div>
            <div class="admin-content">
                ${getAdminTabContent(tab, {businesses, properties, soldProps, materials, clients, enquiries, payments, followups, totalPaid, totalAmount, remainingAmount})}
            </div>
        </div>
    `;
}

function getAdminTabContent(tab, d) {
    switch(tab) {
        case 'overview':
            return `
                <div class="section-header" style="text-align: left; margin-bottom: 25px;">
                    <h2>Dashboard Overview</h2>
                    <p>Welcome back, Er. Syed Abubakar Noman. Full system statistics at a glance.</p>
                </div>
                <div class="stats-grid">
                    <div class="stat-card"><h4>Total Businesses</h4><div class="stat-value">${d.businesses.length}</div></div>
                    <div class="stat-card"><h4>Available Properties</h4><div class="stat-value">${d.properties.filter(p=>p.status==='Available').length}</div></div>
                    <div class="stat-card"><h4>Reserved Properties</h4><div class="stat-value">${d.properties.filter(p=>p.status==='Reserved').length}</div></div>
                    <div class="stat-card"><h4>Sold Properties</h4><div class="stat-value">${d.soldProps.length}</div></div>
                    <div class="stat-card"><h4>Total Clients</h4><div class="stat-value">${d.clients.length}</div></div>
                    <div class="stat-card"><h4>New Enquiries</h4><div class="stat-value">${d.enquiries.length}</div></div>
                    <div class="stat-card"><h4>Pending Follow-ups</h4><div class="stat-value">${d.followups.filter(f=>f.status==='Pending').length}</div></div>
                    <div class="stat-card"><h4>Paid Amount</h4><div class="stat-value" style="font-size:1.4rem;">₹ ${Number(d.totalPaid).toLocaleString('en-IN')}</div></div>
                    <div class="stat-card" style="border-left-color: var(--danger);"><h4>Remaining Balance</h4><div class="stat-value" style="font-size:1.4rem; color:var(--danger);">₹ ${Number(d.remainingAmount).toLocaleString('en-IN')}</div></div>
                </div>
                <h3 style="margin-bottom: 15px; color: var(--primary);">Today's Pending Follow-ups</h3>
                <div class="table-container">
                    <table class="data-table">
                        <thead><tr><th>Date & Time</th><th>Client Name</th><th>Contact</th><th>Purpose</th><th>Status</th></tr></thead>
                        <tbody>
                            ${d.followups.filter(f=>f.status==='Pending').map(f => `
                                <tr>
                                    <td>${f.date} ${f.time}</td>
                                    <td><strong>${f.client}</strong></td>
                                    <td><a href="tel:${f.contact}">${f.contact}</a></td>
                                    <td>${f.purpose}</td>
                                    <td><span class="property-status-badge status-reserved" style="position:static;">${f.status}</span></td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        case 'properties':
            return `
                <div class="flex-between" style="margin-bottom: 20px;">
                    <h2>Property Management</h2>
                    <button class="btn btn-gold" onclick="openPropertyModal()"><i class="fa-solid fa-plus"></i> Add New Property</button>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead><tr><th>Title / Project</th><th>Location</th><th>Plot/No</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
                        <tbody>
                            ${d.properties.map(p => `
                                <tr>
                                    <td><strong>${p.title}</strong><br><small>${p.project}</small></td>
                                    <td>${p.location}</td>
                                    <td>${p.number} (${p.area})</td>
                                    <td>₹ ${Number(p.total).toLocaleString('en-IN')}</td>
                                    <td><span class="property-status-badge status-${p.status.toLowerCase()}" style="position:static;">${p.status}</span></td>
                                    <td>
                                        <div class="action-btns">
                                            <button class="btn btn-primary btn-sm" onclick="editProperty(${p.id})">Edit</button>
                                            ${p.status !== 'Sold' ? `<button class="btn btn-gold btn-sm" onclick="markPropertySold(${p.id})">Mark Sold</button>` : ''}
                                            <button class="btn btn-outline btn-sm" style="color:var(--danger); border-color:var(--danger);" onclick="deleteProperty(${p.id})">Delete</button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        case 'sold':
            return `
                <h2>Sold Out Properties Management</h2>
                <div class="table-container" style="margin-top: 20px;">
                    <table class="data-table">
                        <thead><tr><th>Property / Project</th><th>Location</th><th>Plot / House No</th><th>Purchaser</th><th>Contact</th><th>Sold Amount</th><th>Registry Date</th></tr></thead>
                        <tbody>
                            ${d.soldProps.map(s => `
                                <tr>
                                    <td><strong>${s.title}</strong><br><small>${s.project}</small></td>
                                    <td>${s.location}</td>
                                    <td>${s.number} (${s.area})</td>
                                    <td><strong>${s.purchaserName}</strong></td>
                                    <td><a href="tel:${s.purchaserContact}">${s.purchaserContact}</a></td>
                                    <td>₹ ${Number(s.total).toLocaleString('en-IN')}</td>
                                    <td>${s.registryDate}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        case 'materials':
            return `
                <div class="flex-between" style="margin-bottom: 20px;">
                    <h2>Building Material Catalogue Management</h2>
                    <button class="btn btn-gold" onclick="openMaterialModal()"><i class="fa-solid fa-plus"></i> Add Material</button>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead><tr><th>Material Name</th><th>Category</th><th>Stock Quantity</th><th>Unit</th><th>Price (₹)</th><th>Actions</th></tr></thead>
                        <tbody>
                            ${d.materials.map(m => `
                                <tr>
                                    <td><strong>${m.name}</strong></td>
                                    <td>${m.category}</td>
                                    <td>${m.quantity}</td>
                                    <td>${m.unit}</td>
                                    <td>₹ ${m.price}</td>
                                    <td>
                                        <div class="action-btns">
                                            <button class="btn btn-primary btn-sm" onclick="editMaterial(${m.id})">Edit</button>
                                            <button class="btn btn-outline btn-sm" style="color:var(--danger); border-color:var(--danger);" onclick="deleteMaterial(${m.id})">Delete</button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        case 'clients':
            return `
                <div class="flex-between" style="margin-bottom: 20px;">
                    <h2>Client Database & Enquiries</h2>
                    <button class="btn btn-gold" onclick="openClientModal()"><i class="fa-solid fa-user-plus"></i> Add Client</button>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead><tr><th>Client Name</th><th>Mobile / WhatsApp</th><th>Service / Requirement</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead>
                        <tbody>
                            ${d.clients.map(c => `
                                <tr>
                                    <td><strong>${c.name}</strong></td>
                                    <td><a href="tel:${c.mobile}">${c.mobile}</a></td>
                                    <td>${c.service}<br><small>${c.requirement || ''}</small></td>
                                    <td>${c.location}</td>
                                    <td><span class="property-status-badge status-reserved" style="position:static;">${c.status}</span></td>
                                    <td>
                                        <button class="btn btn-primary btn-sm" onclick="deleteClient(${c.id})">Delete</button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        case 'payments':
            return `
                <div class="flex-between" style="margin-bottom: 20px;">
                    <h2>Payment & Transaction Management</h2>
                    <button class="btn btn-gold" onclick="openPaymentModal()"><i class="fa-solid fa-file-invoice-dollar"></i> Add Payment Record</p>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead><tr><th>Client / Purchaser</th><th>Property Details</th><th>Total Amount</th><th>Paid Amount</th><th>Remaining</th><th>Status</th></tr></thead>
                        <tbody>
                            ${d.payments.map(p => {
                                const rem = Number(p.total) - Number(p.paid);
                                const stat = rem === 0 ? 'Paid' : (p.paid > 0 ? 'Partially Paid' : 'Pending');
                                return `
                                    <tr>
                                        <td><strong>${p.purchaser}</strong><br><a href="tel:${p.contact}">${p.contact}</a></td>
                                        <td>${p.property}</td>
                                        <td>₹ ${Number(p.total).toLocaleString('en-IN')}</td>
                                        <td>₹ ${Number(p.paid).toLocaleString('en-IN')}</td>
                                        <td><strong style="color: ${rem>0?'var(--danger)':'var(--success)'};">₹ ${Number(rem).toLocaleString('en-IN')}</strong></td>
                                        <td><span class="property-status-badge ${rem===0?'status-available':'status-reserved'}" style="position:static;">${stat}</span></td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        case 'schedule':
            return `
                <div class="flex-between" style="margin-bottom: 20px;">
                    <h2>Daily Schedule & Follow-ups</h2>
                    <button class="btn btn-gold" onclick="openFollowupModal()"><i class="fa-solid fa-calendar-plus"></i> Add Follow-up</button>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead><tr><th>Date & Time</th><th>Client Name</th><th>Purpose</th><th>Service / Property</th><th>Status</th><th>Actions</th></tr></thead>
                        <tbody>
                            ${d.followups.map(f => `
                                <tr>
                                    <td>${f.date} ${f.time}</td>
                                    <td><strong>${f.client}</strong><br><a href="tel:${f.contact}">${f.contact}</a></td>
                                    <td>${f.purpose}</td>
                                    <td>${f.service}</td>
                                    <td><span class="property-status-badge status-reserved" style="position:static;">${f.status}</span></td>
                                    <td><button class="btn btn-primary btn-sm" onclick="completeFollowup(${f.id})">Complete</button></td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        default:
            return `<p>Select an option from the admin menu.</p>`;
    }
}

// Admin Modal Actions & CRUD Helpers
function openPropertyModal() {
    const modalHTML = `
        <div class="modal-overlay" id="adminModal">
            <div class="modal-content">
                <button class="modal-close" onclick="closeModal()">&times;</button>
                <h3 style="margin-bottom: 20px; color: var(--primary);">Add New Property</h3>
                <form onsubmit="saveNewProperty(event)">
                    <div class="form-group"><label>Property Title</label><input type="text" id="pTitle" class="form-control" required></div>
                    <div class="form-grid">
                        <div class="form-group"><label>Project Name</label><input type="text" id="pProject" class="form-control" required></div>
                        <div class="form-group"><label>Location</label><input type="text" id="pLoc" class="form-control" required></div>
                        <div class="form-group"><label>Plot / House Number</label><input type="text" id="pNum" class="form-control" required></div>
                        <div class="form-group"><label>Plot Size</label><input type="text" id="pSize" class="form-control" required></div>
                        <div class="form-group"><label>Plot Area</label><input type="text" id="pArea" class="form-control" required></div>
                        <div class="form-group"><label>Price per sq.ft (₹)</label><input type="number" id="pPriceSq" class="form-control" required></div>
                        <div class="form-group"><label>Total Amount (₹)</label><input type="number" id="pTotal" class="form-control" required></div>
                        <div class="form-group"><label>Documents</label><input type="text" id="pDocs" class="form-control" value="Clear Title, Registry Ready" required></div>
                        <div class="form-group"><label>Owner Name</label><input type="text" id="pOwner" class="form-control" value="Er. Syed Abubakar Noman" required></div>
                        <div class="form-group"><label>Owner Contact</label><input type="text" id="pContact" class="form-control" value="7776000339" required></div>
                        <div class="form-group"><label>Status</label><select id="pStatus" class="form-control"><option value="Available">Available</option><option value="Reserved">Reserved</option></select></div>
                        <div class="form-group"><label>Image URL</label><input type="text" id="pImg" class="form-control" value="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&auto=format&fit=crop&q=80"></div>
                    </div>
                    <div class="form-group"><label>Description</label><textarea id="pDesc" class="form-control" required></textarea></div>
                    <button type="submit" class="btn btn-gold" style="width:150px; padding:12px;">Save Property</button>
                </form>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHTML);
}

function closeModal() {
    const m = document.getElementById('adminModal');
    if(m) m.remove();
}

function saveNewProperty(e) {
    e.preventDefault();
    const props = getDB('properties');
    const newProp = {
        id: Date.now(),
        title: document.getElementById('pTitle').value,
        project: document.getElementById('pProject').value,
        location: document.getElementById('pLoc').value,
        number: document.getElementById('pNum').value,
        size: document.getElementById('pSize').value,
        area: document.getElementById('pArea').value,
        pricePerSqFt: Number(document.getElementById('pPriceSq').value),
        total: Number(document.getElementById('pTotal').value),
        docs: document.getElementById('pDocs').value,
        owner: document.getElementById('pOwner').value,
        contact: document.getElementById('pContact').value,
        status: document.getElementById('pStatus').value,
        image: document.getElementById('pImg').value,
        desc: document.getElementById('pDesc').value
    };
    props.push(newProp);
    saveDB('properties', props);
    closeModal();
    renderAdminDashboard(document.getElementById('app-main'), 'properties');
}

function deleteProperty(id) {
    if(confirm('Are you sure you want to delete this property?')) {
        let props = getDB('properties');
        props = props.filter(p => p.id !== id);
        saveDB('properties', props);
        renderAdminDashboard(document.getElementById('app-main'), 'properties');
    }
}

function markPropertySold(id) {
    let props = getDB('properties');
    const propIndex = props.findIndex(p => p.id === id);
    if(propIndex !== -1) {
        const p = props[propIndex];
        const purchaser = prompt('Enter Purchaser Name:', 'Mr. Client');
        const purchaserContact = prompt('Enter Purchaser Contact Number:', '9876543210');
        if(purchaser && purchaserContact) {
            const soldProps = getDB('soldProperties');
            soldProps.push({
                id: Date.now(),
                title: p.title,
                project: p.project,
                location: p.location,
                number: p.number,
                size: p.size,
                area: p.area,
                soldPrice: p.pricePerSqFt,
                total: p.total,
                purchaseDate: new Date().toISOString().split('T')[0],
                registryDate: new Date().toISOString().split('T')[0],
                purchaserName: purchaser,
                purchaserContact: purchaserContact,
                details: p.desc,
                docs: p.docs
            });
            saveDB('soldProperties', soldProps);

            // Also add payment record
            const payments = getDB('payments');
            payments.push({
                id: Date.now(),
                client: purchaser,
                purchaser: purchaser,
                contact: purchaserContact,
                property: `${p.title} (${p.number}, ${p.project})`,
                total: p.total,
                paid: p.total,
                date: new Date().toISOString().split('T')[0],
                mode: 'Bank Transfer',
                txn: 'TXN' + Math.floor(Math.random()*1000000),
                registry: new Date().toISOString().split('T')[0],
                notes: 'Automatically moved from available property.'
            });
            saveDB('payments', payments);

            // Remove from available properties
            props.splice(propIndex, 1);
            saveDB('properties', props);
            alert('Property successfully marked as SOLD and moved to Sold Archive!');
            renderAdminDashboard(document.getElementById('app-main'), 'properties');
        }
    }
}

// Material Add Modal
function openMaterialModal() {
    const modalHTML = `
        <div class="modal-overlay" id="adminModal">
            <div class="modal-content">
                <button class="modal-close" onclick="closeModal()">&times;</button>
                <h3 style="margin-bottom: 20px; color: var(--primary);">Add Building Material</h3>
                <form onsubmit="saveNewMaterial(event)">
                    <div class="form-group"><label>Material Name</label><input type="text" id="mName" class="form-control" required></div>
                    <div class="form-group"><label>Category</label><input type="text" id="mCat" class="form-control" value="Sand / Aggregates" required></div>
                    <div class="form-group"><label>Quantity Available</label><input type="number" id="mQty" class="form-control" required></div>
                    <div class="form-group"><label>Unit (e.g. Brass, Pieces)</label><input type="text" id="mUnit" class="form-control" required></div>
                    <div class="form-group"><label>Price (₹)</label><input type="number" id="mPrice" class="form-control" required></div>
                    <div class="form-group"><label>Image URL</label><input type="text" id="mImg" class="form-control" value="https://images.unsplash.com/photo-1578575437130-527eed3abbec?w=600&auto=format&fit=crop&q=80"></div>
                    <div class="form-group"><label>Description</label><textarea id="mDesc" class="form-control" required></textarea></div>
                    <button type="submit" class="btn btn-gold" style="width:150px; padding:12px;">Save Material</button>
                </form>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHTML);
}

function saveNewMaterial(e) {
    e.preventDefault();
    const mats = getDB('materials');
    mats.push({
        id: Date.now(),
        name: document.getElementById('mName').value,
        category: document.getElementById('mCat').value,
        quantity: Number(document.getElementById('mQty').value),
        unit: document.getElementById('mUnit').value,
        price: Number(document.getElementById('mPrice').value),
        image: document.getElementById('mImg').value,
        desc: document.getElementById('mDesc').value,
        status: 'In Stock'
    });
    saveDB('materials', mats);
    closeModal();
    renderAdminDashboard(document.getElementById('app-main'), 'materials');
}

function deleteMaterial(id) {
    if(confirm('Delete this material?')) {
        let mats = getDB('materials');
        mats = mats.filter(m => m.id !== id);
        saveDB('materials', mats);
        renderAdminDashboard(document.getElementById('app-main'), 'materials');
    }
}

function deleteClient(id) {
    if(confirm('Delete client record?')) {
        let clients = getDB('clients');
        clients = clients.filter(c => c.id !== id);
        saveDB('clients', clients);
        renderAdminDashboard(document.getElementById('app-main'), 'clients');
    }
}

function completeFollowup(id) {
    let followups = getDB('followups');
    const f = followups.find(x => x.id === id);
    if(f) {
        f.status = 'Completed';
        saveDB('followups', followups);
        renderAdminDashboard(document.getElementById('app-main'), 'schedule');
    }
}
